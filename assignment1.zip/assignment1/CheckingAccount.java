package com.meritamerica.assignment1;
//This is the template for a new Checking Account
public class CheckingAccount {
	
	private double balance;
	private double interestRate = 0.0001;

	public CheckingAccount(double balance) {
		super();
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public double futureValue(int years) {
		double factor = 1+interestRate;
		return Math.pow(factor, years) * balance;
	}
	//	FV=balance * (1+i) ^n;
	public boolean withdraw (double amount) {
	if (amount<balance) {
		System.out.println(balance-amount);
		balance = balance - amount;
		return true;
	}
	else
		return false;
	}
	
	public boolean deposit (double amount)
	{
	if (amount>0) {
		System.out.println(balance+amount);
		balance = balance + amount;
		return true;
	}
	else
		return false;
	}

	@Override
	public String toString() {
		return "CheckingAccount [balance=" + balance + ", Interest Rate=" + interestRate + "Future Value = "
				+ futureValue(3) +"]";
	}
}
