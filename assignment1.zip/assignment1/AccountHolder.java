package com.meritamerica.assignment1;

public class AccountHolder {
	
}