package com.meritamerica.assignment1;
// This is the template for a new Savings Account
public class SavingsAccount {
	private double balance;
	private double interestRate = 0.01;

	public SavingsAccount(double balance) {
		super();
		this.balance = balance;
	}
	public double getBalance() {
		return balance;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public double futureValue(int years) {
		double factor = 1+interestRate;
		return Math.pow(factor, years) * balance;
	}

	public boolean withdraw (double amount) {
	if (amount<balance) {
		System.out.println(balance);
		balance = balance - amount;
		return true;
	}
	else
		return false;
	}
	public boolean deposit (double amount)
	{
	if (amount>0) {
		System.out.println(balance+amount);
		balance = balance + amount;
		return true;
	}
	else
		return false;
	}
//to string
	@Override
	public String toString() {
		return "SavingsAccount [balance=" + balance + ", interestRate=" + interestRate + "]";
	}
}
/*
 * SavingsAccount(double openingBalance)
double getBalance()
double getInterestRate()
boolean withdraw(double amount)
boolean deposit(double amount)
double futureValue(int years)
String toString()
Sample output:
Savings Account Balance: $1000
Savings Account Interest Rate: 0.01
Savings Account Balance in 3 years: $1030.03

 */
