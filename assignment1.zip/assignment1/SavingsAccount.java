package com.meritamerica.assignment1;

public class SavingsAccount {
	
}