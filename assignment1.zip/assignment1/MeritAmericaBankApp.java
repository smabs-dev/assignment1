package com.meritamerica.assignment1;

public class MeritAmericaBankApp {
	
}