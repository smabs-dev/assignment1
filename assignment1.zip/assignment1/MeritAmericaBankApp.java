package com.meritamerica.assignment1;

public class MeritAmericaBankApp {

	public static void main(String[] args) {

AccountHolder actHolderRahmanJ= new AccountHolder("Rahman", " ", "Jones", "123456789", 100.0, 1000.0);
System.out.println(actHolderRahmanJ);
actHolderRahmanJ.getCheckingAccount().deposit(500.00);
actHolderRahmanJ.getSavingsAccount().withdraw(800.00);
System.out.println(actHolderRahmanJ.getCheckingAccount().toString());
System.out.println(actHolderRahmanJ.getSavingsAccount().toString());
AccountHolder actHolderBillB = new AccountHolder("Bill", " ", "Belemy", "23456891", 200.0, 500.0);
System.out.println(actHolderBillB);
actHolderBillB.getCheckingAccount().deposit(-500.00);
actHolderBillB.getSavingsAccount().withdraw(600.00);
System.out.println(actHolderBillB.getCheckingAccount().toString());
System.out.println(actHolderBillB.getSavingsAccount().toString());
	}
}
